﻿namespace MvvM_Notes;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
