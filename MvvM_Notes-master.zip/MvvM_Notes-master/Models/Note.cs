﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MvvM_Notes.Models
{
    public class Note
    {
        public string Head { get; set; }
        public string Text { get; set; }
    }
}
